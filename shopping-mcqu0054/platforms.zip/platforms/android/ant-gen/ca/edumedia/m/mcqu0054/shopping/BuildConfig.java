/** Automatically generated file. DO NOT MODIFY */
package ca.edumedia.m.mcqu0054.shopping;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}